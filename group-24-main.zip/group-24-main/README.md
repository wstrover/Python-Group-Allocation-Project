# GitLab repository for CO2201 Group Projects

## Please update this readme file with installation instructions as soon as is possible


Members Commit names:
William Strover(ws144) may be shown as W Strover or William in commits.




Installation instructions:
The project should have been entirely pushed to the branch "CodeBase". 
the project there should be able to be cloned (We used PyCharm Professional version)
From In pycharm just make sure that all imports are installed eg flask is installed (could be done by "pip install flask" in terminal)
then run the "run.py" python script
go to the given address in preferabley a chrome tab, it's always been so far(http://127.0.0.1:5000/)
(preferabley start on http://127.0.0.1:5000/signIn)

PS. the excel sheet used for testing should be in the main branch
